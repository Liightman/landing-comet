<?php 
 
function exposed_featured_post($atts){
	extract(shortcode_atts(array(
	    'ftp_sec_ttl' =>'',
	    'ftp_per_pag' =>'3',
	    'ftp_per_ordr' =>'DESC',
	    'ftp_cat' =>''
	), $atts));
	ob_start(); ?>
    <div class="featured-post mar-btm-50" id="featured_post">
        <div>
            <h4 class="section-header"><span><?php echo esc_html($ftp_sec_ttl); ?></span></h4>
            <div class="row">  
				<?php $sticky = implode(',', get_option( 'sticky_posts' ) );
				query_posts(array('cat'=> $ftp_cat,'post_type'=>'post','order'=> $ftp_per_ordr,'posts_per_page'=> $ftp_per_pag,'post__not_in'  => array($sticky))); 
				while ( have_posts() ) : the_post(); ?>
	                <div class="col-md-4 col-sm-12">
	                    <div>
	                    	<?php 
				        	$exposed_img_chk = 'noimg';
				        	if(has_post_thumbnail()): ?>
		                        <div class="pos-relative">
		                        	<?php the_post_thumbnail('exposed-featured-post',array('class'=>'')); ?> 
									<div class="overlay"></div>
									<?php 
										$categories = get_the_category();
										if ( ! empty( $categories ) ) {
										    echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '" class="button yellow-bg left-bottom">' . esc_html( $categories[0]->name ) . '</a>';
										}
									?>  
		                        </div>   
				            <?php 
				            $exposed_img_chk = '';
				            endif; ?>   
	                        <div>
	                            <h4 class="cp-semi-bold mar-top-30 mar-btm-10 <?php echo esc_attr($exposed_img_chk); ?>"><a href="<?php the_permalink(); ?>" class="black"><?php the_title(); ?></a></h4>
	                            <span class="font-10 letter-spacing-1 post-date"><i class="fa fa-clock-o mar-right-10 font-14"></i><?php echo get_the_date('M n, Y');?></span>
	                            <p class="mar-top-10 mar-bottom-responsive-10"><?php echo wp_trim_words(get_the_content(),13,''); ?></p>
	                        </div>
	                    </div>
	                </div>
				<?php endwhile; wp_reset_query();?> 
            </div><!--/.row-->
        </div><!--/.container-->
    </div><!--/#featured_post-->
<?php return ob_get_clean();
}
add_shortcode('featured_post','exposed_featured_post');


function exposed_top_post($atts){
	extract(shortcode_atts(array(
	    'top_sec_ttl' => '',
	    'top_per_pg' => 3,
	    'top_order_typ' =>'DESC'
	), $atts));
	ob_start(); ?> 
    <div>
        <h4 class="section-header"><span><?php echo esc_html($top_sec_ttl); ?></span></h4> 
        <?php 
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;  
        query_posts(array('post_type'=>'post','posts_per_page'=> $top_per_pg,'order'=> $top_order_typ,'post__not_in'  => get_option( 'sticky_posts' ),'paged' => $paged));
        while(have_posts()): the_post(); ?>
	        <div class="row">
	            <div class="col-sm-12  mar-btm-15"> 
	            	<?php $exposed_post_format = get_post_format();
	            	if(('video'== $exposed_post_format) || ('0'== $exposed_post_format)){ 
			        	$exposed_img_chk = 'noimg';
			        	if(has_post_thumbnail()): ?>
		                <div class="pos-relative mar-top-25">
		                    <?php the_post_thumbnail('exposed-featured-post',array('class'=>'')); ?>
		                    <div class="overlay">
		                    	<?php  
		                    	if('video'== $exposed_post_format){ 
		                    		$exposed_post_vdo = get_post_meta(get_the_ID(),'_exposed_post_formate_vdo',true);
		                    		echo '<a href="#" class="video-player"><i class="fa fa-play-circle-o light-white font-60"></i></a>';
		                    	}
		                    	?> 
		                    </div>
							<?php 
								$categories = get_the_category();
								if ( ! empty( $categories ) ) {
								    echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '" class="button yellow-bg left-bottom">' . esc_html( $categories[0]->name ) . '</a>';
								}
							?> 
		                </div>
		            <?php 
		            $exposed_img_chk = '';
		            endif; }else{ ?>  
		                <?php 
		                	$exposed_new_url = array();
		                    $exposed_gallery_images = get_post_meta( get_the_ID(), '_exposed_post_galery_list', true );
		                    foreach ( (array) $exposed_gallery_images as $exposed_gallery_images_id => $exposed_gallery_images_url ) { 
		                    $exposed_img_url = wp_get_attachment_image_src( $exposed_gallery_images_id, 'exposed-galery-single-slider' ); 
		                         $exposed_new_url[] = $exposed_img_url[0];
		                    } 
		                ?>
						<?php if($exposed_new_url[0] !=''): ?>
	                        <div class="col-md-8 col-sm-12">
	                            <div class="row">
	                            <div class="mar-0x2x0x0 mar-0x0x2x0-responsive">
	                                <div class="pos-relative">
	                                    <img src="<?php echo esc_url($exposed_new_url[0]); ?>" class="img-responsive max-height-390" alt="2">
	                                    <div class="overlay"></div>    
	                                </div>
									<a href="#" class="button yellow-bg left-bottom">News</a>
	                            </div>
	                            </div>    
	                        </div>
						<?php endif; ?>
						<?php if($exposed_new_url[1] !=''): ?>
						    <div class="col-md-4 col-sm-12">
						        <div class="row">
						            <div class="mar-0x0x2x0">
						                <div class="pos-relative">
						                    <img src="<?php echo esc_url($exposed_new_url[1]); ?>" class="img-responsive glry" alt="2">
						                    <div class="overlay"></div>    
						                </div>
						            </div>
						            <?php if($exposed_new_url[2] !=''): ?>
						                <div>    
						                    <div class="pos-relative">
						                        <img src="<?php echo esc_url($exposed_new_url[2]); ?>" class="img-responsive glry" alt="2">
						                        <div class="overlay"></div>    
						                    </div>
						                </div>
						            <?php endif; ?>
						        </div>    
						    </div>
						<?php endif; ?>

					<?php $exposed_img_chk = ''; } ?>

	                <div class="post-content">
	                    <h2 class="cp-semi-bold mar-top-30 mar-btm-10 <?php echo esc_attr($exposed_img_chk); ?>"><a href="<?php the_permalink(); ?>" class="black"><?php the_title(); ?></a></h2> 
	                    <span class="font-10 letter-spacing-1 post-date"><i class="fa fa-clock-o mar-right-10 font-14"></i><?php echo get_the_date('M n, Y');?></span>
	                    <p class="mar-top-10 mar-btm-20"><?php echo wp_trim_words(get_the_content(),63,''); ?></p>
	                    <a class="font-10 black oswald letter-spacing-1 border-btm-ash inline-block mar-btm-15" href="<?php the_permalink(); ?>"><?php esc_html_e('READ MORE','exposed'); ?></a>
	                </div>
	                <hr>
	            </div>
	        </div><!--/.row-->
	    <?php endwhile; ?> 
	        <div class="row">
	            <div class="col-sm-12">
	                <nav>
	                    <?php exposed_pagination();  ?>
	                </nav>
	            </div>
	        </div><!--/.row-->
        <?php  wp_reset_query();  ?>
     </div><!--/.col-md-8--> 
<?php return ob_get_clean();
}
add_shortcode('top_post','exposed_top_post');


 
function exposed_trendy_post($atts){
	extract(shortcode_atts(array(
	    'trnd_sec_ttl' =>'',
	    'trnd_per_pg' => 4,
	    'trnd_order_typ' =>'DESC',
	    'trnd_cat' =>''
	), $atts));
	ob_start(); ?>
		<div class="trndy">
		    <h4 class="section-header"><span><?php echo esc_html($trnd_sec_ttl); ?></span></h4>
		    <div class="row">
		    	<?php $trnd_post = '';
				query_posts(array('cat'=> $trnd_cat,'post_type'=>'post','posts_per_page'=>1,'post__not_in'  => get_option( 'sticky_posts' ))); 
				while ( have_posts() ) : the_post(); 
				$trnd_post = get_the_id(); ?>
			        <div class="col-md-6 col-sm-12">
			            <div>
							<?php 
				        	$exposed_img_chk = 'noimg';
				        	if(has_post_thumbnail()): ?> 
				                <div class="pos-relative">
				                    <?php the_post_thumbnail('exposed-featured-post',array('class'=>'')); ?> 
				                    <div class="overlay"></div>
									<?php 
										$categories = get_the_category();
										foreach ($categories as $key => $value) {
											if($value->term_id == $trnd_cat){
												echo '<a href="' . esc_url( get_category_link( $value->term_id ) ) . '" class="button yellow-bg left-bottom">' . esc_html( $value->name ) . '</a>';
											}
										} 
									?>   
				                </div>    
				            <?php 
				            $exposed_img_chk = ''; 
				            endif; ?>
  
			                <div>
			                    <h4 class="cp-semi-bold mar-top-30 mar-btm-10 <?php echo esc_attr($exposed_img_chk); ?>"><a href="<?php the_permalink(); ?>" class="black"><?php the_title(); ?></a></h4>
			                    <span class="font-10 letter-spacing-1 post-date"><i class="fa fa-clock-o mar-right-10 font-14"></i><?php echo get_the_date('M n, Y');?></span>
			                    <p class="mar-top-10 mar-bottom-responsive-30"><?php echo wp_trim_words(get_the_content(),13,''); ?></p>
			                </div>
			            </div>
			        </div>
				<?php endwhile; wp_reset_query();?> 
		        
		        <div class="col-md-6 col-sm-12"> 
			    	<?php 
					query_posts(array('cat'=> $trnd_cat,'post_type'=>'post','order'=> $trnd_order_typ,'posts_per_page'=>$trnd_per_pg,'post__not_in'  =>array($trnd_post, get_option( 'sticky_posts' )) )); 
					while ( have_posts() ) : the_post();  
					?>
						<div class="trnd">
				            <div class="min-height-65">
					            <?php 
					        	$exposed_img_chk = 'noimg';
					        	if(has_post_thumbnail()): ?>
					                <div class="sidebar-img">
					                    <?php the_post_thumbnail('exposed-side-post',array('class'=>'')); ?> 
					                </div> 
					            <?php 
					            $exposed_img_chk = ''; 
					            endif; ?>
				                <div class="sidebar-content">
				                    <h5 class="mar-btm-5"><a href="<?php the_permalink(); ?>" class="black"><?php the_title(); ?></a></h5>
				                    <span class="font-10 letter-spacing-1 post-date"><i class="fa fa-clock-o mar-right-10 font-14"></i><?php echo get_the_date('M n, Y');?></span>
				                </div>
				            </div>
				            <hr class="mar-18x0">
				        </div>
					<?php endwhile; wp_reset_query();?>  
		        </div> 
		    </div> 
		</div> 
<?php return ob_get_clean();
}
add_shortcode('trendy_post','exposed_trendy_post');


 
function exposed_media_post($atts){
	extract(shortcode_atts(array(
	    'mda_sec_ttl' =>'',
	    'mda_per_pg' => 3,
	    'mda_order_typ' => 'DESC',
	    'mda_cat' =>''
	), $atts));
	ob_start(); ?>
	    <div class="fashion-news mar-btm-50" id="fashion_news"> 
	        <h4 class="section-header"><span><?php echo esc_html($mda_sec_ttl); ?></span></h4>
	        <div class="row">
		    	<?php 
				query_posts(array('cat'=> $mda_cat,'post_type'=>'post','order'=>$mda_order_typ,'posts_per_page'=>$mda_per_pg,'post__not_in'  =>  get_option( 'sticky_posts' ))); 
				while ( have_posts() ) : the_post();  
				?> 
		            <div class="col-md-4 col-sm-12">
		                <div class="pos-relative mar-bottom-responsive-30">
	                    	<?php 
								if(has_post_thumbnail()){
									the_post_thumbnail('exposed-featured-post',array('class'=>'img-responsive'));
								}else{
									echo '<img src="http://placehold.it/320x256" />';
								}
	                    	 ?> 
	                        <div class="overlay">
	                            <div class="fashion-inner"> 
									<?php 
										$categories = get_the_category();
										foreach ($categories as $key => $value) {
											if($value->term_id == $mda_cat){
												echo '<a href="' . esc_url( get_category_link( $value->term_id ) ) . '" class="button yellow-bg">' . esc_html( $value->name ) . '</a>';
											}
										} 
									?>     
	                                <h3 class="cp-semi-bold mar-top-7 mar-btm-5"><a href="<?php the_permalink(); ?>" class="white"><?php the_title(); ?></a></h3>
	                                <span class="font-10 letter-spacing-1 white post-date"><i class="fa fa-clock-o mar-right-10 font-14"></i><?php echo get_the_date('M n, Y');?></span>   
	                            </div>
	                        </div>
		                </div>
		            </div>
				<?php endwhile; wp_reset_query();?>  
	        </div> 
	    </div> 
<?php return ob_get_clean();
}
add_shortcode('media_post','exposed_media_post');


 
function exposed_game_sports_post($atts){
	extract(shortcode_atts(array(
	    'gmsp_sec_ttl' =>'',
	    'gmsp_per_pg' => 4,
	    'gmsp_order_typ' =>'DESC',
	    'gmsp_cat' =>''
	), $atts));
	ob_start(); ?>
		<div class="gam_sprt">
		    <h4 class="section-header"><span><?php echo esc_html($gmsp_sec_ttl); ?></span></h4>
		    <div class="row">
		    	<?php $gmsp_post = array();
				query_posts(array('cat'=> $gmsp_cat,'post_type'=>'post','posts_per_page'=>2,'post__not_in'  => get_option( 'sticky_posts' ))); 
				while ( have_posts() ) : the_post(); 
				$gmsp_post[] = get_the_ID(); ?> 	    	
			        <div class="col-md-6 col-sm-12">
			            <div class="pos-relative mar-btm-30">
			                 <?php 
								if(has_post_thumbnail()){
									the_post_thumbnail('exposed-featured-post',array('class'=>'img-responsive'));
								}else{
									echo '<img src="http://placehold.it/320x256" />';
								}
	                    	 ?> 
			                <div class="overlay"> 
			                    <div class="fashion-inner"> 
									<?php 
										$categories = get_the_category();
										foreach ($categories as $key => $value) {
											if($value->term_id == $gmsp_cat){
												echo '<a href="' . esc_url( get_category_link( $value->term_id ) ) . '" class="button yellow-bg">' . esc_html( $value->name ) . '</a>';
											}
										} 
									?> 
			                        <h3 class="cp-semi-bold mar-top-7 mar-btm-5"><a href="<?php the_permalink(); ?>" class="white"><?php the_title(); ?></a></h3>
			                        <span class="font-10 letter-spacing-1 white post-date"><i class="fa fa-clock-o mar-right-10 font-14"></i><?php echo get_the_date('M n, Y');?></span> 
			                    </div>
			                </div>
			            </div>
			        </div>
				<?php endwhile; wp_reset_query();?>  
		    </div><!--/.row-->
		    <div class="row">
		    	<?php  $stikcy = get_option( 'sticky_posts' ); $post_not = array_merge($gmsp_post,$stikcy);
				query_posts(array('cat'=> $gmsp_cat,'post_type'=>'post','order'=>$gmsp_order_typ,'posts_per_page'=>$gmsp_per_pg,'post__not_in' =>  $post_not )); 
				while ( have_posts() ) : the_post(); ?> 
			        <div class="col-md-6 col-sm-12 gmtblk">
			            <div class="min-height-65">
			            	<?php 
				        	$exposed_img_chk = 'noimg';
				        	if(has_post_thumbnail()): ?> 
				                <div class="sidebar-img">
				                    <?php the_post_thumbnail('exposed-side-post',array('class'=>'')); ?>
				                </div>
				            <?php 
				            $exposed_img_chk = ''; 
				            endif; ?>
			                <div class="sidebar-content">
			                    <h5 class="mar-btm-5"><a href="<?php the_permalink(); ?>" class="black"><?php the_title(); ?></a> </h5>
			                    <span class="font-10 letter-spacing-1 post-date"><i class="fa fa-clock-o mar-right-10 font-14"></i><?php echo get_the_date('M n, Y');?></span>
			                </div>
			            </div>
			            <hr class="mar-18x0"> 
			        </div>
				<?php endwhile; wp_reset_query();?> 

		    </div> 
		</div> 
<?php return ob_get_clean();
}
add_shortcode('game_sports_post','exposed_game_sports_post');


 
function exposed_game_sports_massonry_post($atts){
	extract(shortcode_atts(array(
	    'mspmsnry_thumb' =>'',
	    'cat_bgc' =>'yellow-bg',
	    'gmspmsnry_post' =>''
	), $atts)); 
        $gmsonry_image = wp_get_attachment_image_src($mspmsnry_thumb,'gmsnry-img');
        $gmsonry_img = $gmsonry_image[0]; 
	ob_start(); ?>
        <div class="row">     
            <div class="pos-relative imgglry">
                <img src="<?php echo esc_url($gmsonry_img); ?>" class="img-responsive1" alt="Massonry">
                <?php query_posts(array('p'=> $gmspmsnry_post,'post_type'=>'post')); 
                while ( have_posts() ) : the_post(); ?>
	                <div class="overlay">        
	                    <div class="fashion-inner">
							<?php  
								$categories = get_the_category();
								if ( ! empty( $categories ) ) {
								    echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '" class="button '.$cat_bgc.'">' . esc_html( $categories[0]->name ) . '</a>';
								}
							?>   
	                        <h3 class="cp-semi-bold mar-top-7 mar-btm-5"><a href="<?php the_permalink(); ?>" class="white"><?php the_title(); ?></a></h3>
	                        <span class="font-10 letter-spacing-1 white post-date"><i class="fa fa-clock-o mar-right-10 font-14"></i><?php echo get_the_date('M n, Y');?></span>
	                    </div>
	                </div>  
                <?php endwhile; wp_reset_query();?>  
            </div>
        </div>
<?php return ob_get_clean();
}
add_shortcode('game_sports_massonry_post','exposed_game_sports_massonry_post');


function exposed_breaking_post($atts){
	extract(shortcode_atts(array(
	    'brk_sec_ttl' =>'',
	    'brk_per_pg' => 6,
	    'brk_order_typ' =>'DESC',
	    'brk_cat' =>''
	), $atts));  
	ob_start(); ?>
        <div class="business mar-btm-50" id="business">
            <div class=""> 
                <div>
                    <h4 class="section-header"><span><?php echo esc_html($brk_sec_ttl); ?></span></h4>
			    	<?php $brek_post = ''; $sticky = implode(',', get_option( 'sticky_posts' ) );
					query_posts(array('cat'=> $brk_cat,'post_type'=>'post','posts_per_page'=>1,'post__not_in'  => array($sticky))); 
					while ( have_posts() ) : the_post(); 
					$brek_post = get_the_id(); ?> 	 
				        <?php if(has_post_thumbnail()): ?>
		                    <div class="pos-relative">
		                    	<?php the_post_thumbnail('', array('class'=>'img-responsive1')); ?>  
		                        <div class="overlay"></div> 
								<?php 
									$categories = get_the_category();
									foreach ($categories as $key => $value) {
										if($value->term_id == $brk_cat){
											echo '<a href="' . esc_url( get_category_link( $value->term_id ) ) . '" class="button yellow-bg left-bottom">' . esc_html( $value->name ) . '</a>';
										}
									} 
								?>    
		                    </div>
		                <?php endif; ?>
	                    <div class="mar-top-30">
	                        <h2 class="cp-semi-bold mar-btm-10"><a href="<?php the_permalink(); ?>" class="black"><?php the_title(); ?></a></h2>
	                        <span class="font-10 letter-spacing-1 post-date"><i class="fa fa-clock-o mar-right-10 font-14"></i><?php echo get_the_date('M n, Y');?></span>
	                        <p class="mar-top-10 mar-btm-20"><?php echo wp_trim_words(get_the_content(),70,''); ?></p>
	                        <a class="font-10 black oswald letter-spacing-1 border-btm-ash inline-block mar-btm-20" href="<?php the_permalink(); ?>"><?php esc_html_e('READ MORE','exposed'); ?></a>
	                     </div>   
	                    <hr>
					<?php endwhile; wp_reset_query();?>  

			    	<?php $sticky = implode(',', get_option( 'sticky_posts' ) ); 
					query_posts(array('cat'=> $brk_cat,'post_type'=>'post','order'=>$brk_order_typ,'posts_per_page'=>$brk_per_pg,'post__not_in'  =>array( $brek_post,$sticky ) )); 
					while ( have_posts() ) : the_post(); ?>  
                        <div class="list-sks">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="mar-btm-15">
                                    	<?php if(has_post_thumbnail()): ?>
	                                        <div class="sidebar-img2">
	                                            <div class="pos-relative">
			                    					<?php the_post_thumbnail('', array('class'=>'img-responsive')); ?>   
	                                                <div class="overlay"></div>    
	                                            </div>
	                                        </div>
                                        <?php endif; ?>
                                        <div class="sidebar-content">
                                            <h5 class="mar-btm-5"><a href="<?php the_permalink(); ?>" class="black"><?php the_title(); ?></a></h5>
                                            <span class="font-10 letter-spacing-1 post-date"><i class="fa fa-clock-o mar-right-10 font-14"></i><?php echo get_the_date('M n, Y');?></span>
                                            <p class="mar-top-10" ><?php echo wp_trim_words(get_the_content(),16,''); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>    
                        </div>
					<?php endwhile; wp_reset_query();?>   
                <a  class="block-button yellow-bg load-more-btn "><?php esc_html_e('Load More','exposed'); ?></a> 
                </div>  
            </div><!--/.container--> 
            <div class="clear-fix"></div> 
        </div><!--/#business-->
<?php return ob_get_clean();
}
add_shortcode('breaking_post','exposed_breaking_post');

