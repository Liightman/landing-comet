<?php 

add_action( 'init', 'exposed_post_type', 0 );
function exposed_post_type(){

	// Slider post type
	$port_p_labels = array(
		'name'                  => _x( 'Sliders', 'Post Type General Name', 'exposed' ),
		'singular_name'         => _x( 'Slider', 'Post Type Singular Name', 'exposed' ),
		'menu_name'             => esc_html__( 'Sliders', 'exposed' ),
		'name_admin_bar'        => esc_html__( 'Slider', 'exposed' ),
		'archives'              => esc_html__( 'Sliders Archives', 'exposed' ),
		'parent_item_colon'     => esc_html__( 'Parent Slider:', 'exposed' ),
		'all_items'             => esc_html__( 'All Sliders', 'exposed' ),
		'add_new_item'          => esc_html__( 'Add New Slider', 'exposed' ),
		'add_new'               => esc_html__( 'Add New', 'exposed' ),
		'new_item'              => esc_html__( 'New Slider', 'exposed' ),
		'edit_item'             => esc_html__( 'Edit Slider', 'exposed' ),
		'update_item'           => esc_html__( 'Update Slider', 'exposed' ),
		'view_item'             => esc_html__( 'View Slider', 'exposed' ),
		'search_items'          => esc_html__( 'Search Slider', 'exposed' ),
		'not_found'             => esc_html__( 'Not found', 'exposed' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'exposed' ),
		'featured_image'        => esc_html__( 'Featured Image', 'exposed' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'exposed' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'exposed' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'exposed' ),
		'insert_into_item'      => esc_html__( 'Insert into Slider', 'exposed' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this Slider', 'exposed' ),
		'items_list'            => esc_html__( 'Sliders list', 'exposed' ),
		'items_list_navigation' => esc_html__( 'Sliders list navigation', 'exposed' ),
		'filter_items_list'     => esc_html__( 'Filter Sliders list', 'exposed' ),
	);

	$port_p_args = array(
		'label'                 => esc_html__( 'Slider', 'exposed' ),
		'description'           => esc_html__( 'Sliders Description', 'exposed' ),
		'labels'                => $port_p_labels,
		'supports'              => array( 'title', 'editor', 'author', 'thumbnail', 'comments', 'page-attributes', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-grid-view',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'post',
	);
	register_post_type( 'sliders', $port_p_args );



}