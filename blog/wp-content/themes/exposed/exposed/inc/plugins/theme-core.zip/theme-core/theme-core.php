<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://wowtheme.net/sajib
 * @since             1.0.0
 * @package           Theme_Core
 *
 * @wordpress-plugin
 * Plugin Name:       Theme Core
 * Plugin URI:        http://wowtheme.net
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Sajib Talukder
 * Author URI:        http://wowtheme.net/sajib
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       theme-core
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
 
/**
 * Post Type 
 */
require plugin_dir_path( __FILE__ ) . 'includes/post-type.php';

/**
 * Taxonomy
 */
require plugin_dir_path( __FILE__ ) . 'includes/taxonomy.php';

/**
 * Shortcode
 */
require plugin_dir_path( __FILE__ ) . 'includes/shortcodes.php';

/**
 * One Click Demo Setup
 */
require plugin_dir_path( __FILE__ ) . 'one-click-demo/init.php';


// admin area css
function exposed_admin_styles() {
   ?>
    <style type="text/css">
    	.rs-update-notice-wrap,
    	.redux-timer,
    	#wpfooter #footer-left,
    	.redux-dev-qtip,
        .rAds span a img,
        .redux-notice,
        #redux_blast_1454922210,
		#admin_config{
			display: none !important;
		}
		.field-menuposition .edit-menu-item-menuposition,
		.field-mtype .edit-menu-item-mtype,
		.field-column .edit-menu-item-column{
			width: 100px;
		}
		ul#menu-to-edit li.menu-item-depth-6 .hidn,
		ul#menu-to-edit li.menu-item-depth-5 .hidn,
		ul#menu-to-edit li.menu-item-depth-4 .hidn,
		ul#menu-to-edit li.menu-item-depth-3 .hidn,
		ul#menu-to-edit li.menu-item-depth-2 .field-enablemegamenu, 
		ul#menu-to-edit li.menu-item-depth-2 .field-mtype ,
		ul#menu-to-edit li.menu-item-depth-2 .field-column , 
		ul#menu-to-edit li.menu-item-depth-1 .cs-fieldset, 
		ul#menu-to-edit li.menu-item-depth-1 .field-mtype ,
		ul#menu-to-edit li.menu-item-depth-1 .field-column ,
		ul#menu-to-edit li.menu-item-depth-1 .field-enablemegamenu ,
		ul#menu-to-edit li.menu-item-depth-0 .cs-fieldset ,
		ul#menu-to-edit li.menu-item-depth-0 .field-mimg,
		ul#menu-to-edit li.menu-item-depth-0 .field-columntitle{
			display: none;
		}
		.menu-item-settings {
		    overflow: hidden;
		}
		.field-mimg img#upimage {
		    width: 100px;
		    max-height: 100px; 
		}
    </style>
    <?php
}
add_action('admin_head', 'exposed_admin_styles');
 

/**
 * Post Formate Display Procedure.
 */
add_action('admin_print_scripts', 'exposed_display_procedure', 1000);

function exposed_display_procedure(){ ?>
	<?php if(get_post_type() == 'post') : ?>
		<script>
			jQuery(document).ready(function(){
				var id = jQuery( 'input[name="post_format"]:checked' ).attr('id');
				if(id == 'post-format-audio'){
					jQuery('.cmb2-id--exposed-post-audio').show();
				}else{
					jQuery('.cmb2-id--exposed-post-audio').hide();
				} 
				if(id == 'post-format-video'){
					jQuery('.cmb2-id--exposed-post-formate-vdo').show();
				}else{
					jQuery('.cmb2-id--exposed-post-formate-vdo').hide();
				} 
				
				if(id == 'post-format-gallery'){
					jQuery('.cmb2-id--exposed-post-galery-list').show();
				}else{
					jQuery('.cmb2-id--exposed-post-galery-list').hide();
				} 

				if(id == 'post-format-0'){
					jQuery('.cmb2-id--exposed-post-gmap').show();
					jQuery('.cmb2-id--exposed-post-aftr-ftimg').hide();
				}else{
					jQuery('.cmb2-id--exposed-post-gmap').hide();
					jQuery('.cmb2-id--exposed-post-aftr-ftimg').show();
				}
				jQuery( 'input[name="post_format"]' ).change(function(){
						jQuery('.cmb2-id--exposed-post-formate-vdo').hide(); 
						jQuery('.cmb2-id--exposed-post-galery-list').hide();
					jQuery('.cmb2-id--exposed-post-aftr-ftimg').hide();
						jQuery('.cmb2-id--exposed-post-gmap').hide();
						jQuery('.cmb2-id--exposed-post-audio').hide();

					var id = jQuery( 'input[name="post_format"]:checked' ).attr('id');

					if(id == 'post-format-audio'){
						jQuery('.cmb2-id--exposed-post-audio').show();
					}else{
						jQuery('.cmb2-id--exposed-post-audio').hide();
					} 
					if(id == 'post-format-video'){
						jQuery('.cmb2-id--exposed-post-formate-vdo').show();
					}else{
						jQuery('.cmb2-id--exposed-post-formate-vdo').hide();
					} 
					
					if(id == 'post-format-gallery'){
						jQuery('.cmb2-id--exposed-post-galery-list').show();
					}else{
						jQuery('.cmb2-id--exposed-post-galery-list').hide();
					} 
					if(id == 'post-format-0'){
						jQuery('.cmb2-id--exposed-post-gmap').show();
						jQuery('.cmb2-id--exposed-post-aftr-ftimg').hide();
					}else{
						jQuery('.cmb2-id--exposed-post-gmap').hide();
						jQuery('.cmb2-id--exposed-post-aftr-ftimg').show();
					}
					 

				});
			})
		</script> 
	<?php endif; ?>
	<?php if(get_post_type() == 'page') : ?>
		<script>
			jQuery(document).ready(function(){
				var id = jQuery( 'input[name="_exposed_header_style"]:checked' ).attr('id');
				if(id == '_exposed_header_style2'){
					jQuery('.cmb2-id--exposed-page-banner').show();
				}else{
					jQuery('.cmb2-id--exposed-page-banner').hide();
				}
				if(id == '_exposed_header_style3'){
					jQuery('.cmb2-id--exposed-rev-slidr-alias').show();
				}else{
					jQuery('.cmb2-id--exposed-rev-slidr-alias').hide();
				}

				jQuery( 'input[name="_exposed_header_style"]' ).change(function(){
					jQuery('.cmb2-id--exposed-page-banner').hide(); 
					jQuery('.cmb2-id--exposed-rev-slidr-alias').hide(); 

					var id = jQuery( 'input[name="_exposed_header_style"]:checked' ).attr('id');

					if(id == '_exposed_header_style2'){
						jQuery('.cmb2-id--exposed-page-banner').show();
					}else{
						jQuery('.cmb2-id--exposed-page-banner').hide();
					}
					
					if(id == '_exposed_header_style3'){
						jQuery('.cmb2-id--exposed-rev-slidr-alias').show();
					}else{
						jQuery('.cmb2-id--exposed-rev-slidr-alias').hide();
					}

				});
			})
		</script> 
	<?php endif; ?>
<?php }
